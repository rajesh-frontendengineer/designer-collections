import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { SuggestDiagnosisComponent } from './suggest-diagnosis/suggest-diagnosis.component';
import { DiagnosisResultsComponent } from './diagnosis-results/diagnosis-results.component';
import { DiagnosisResultsResolver } from './resolvers/diagnosis-results-resolver';
import { DiagnosisTriageToolComponent } from './diagnosis-triage-tool/diagnosis-triage-tool.component';
import { SymptomDetailsComponent } from './symptom-details/symptom-details.component';
import { ArticleDetailsComponent } from './article-details/article-details.component';
import { KnowledgeWindowComponent } from './knowledge-window/knowledge-window.component';

const routes: Routes = [
  {
    path: 'suggest-diagnosis',
    children: [
      {
        path: '',
        component: SuggestDiagnosisComponent
      },
      {
        path: ':age/:gender/:region/:pregnant/:symptoms',
        component: SuggestDiagnosisComponent
        // resolve: {diagnosiseResults: DiagnosisResultsResolver}
      }
    ]
  },
  { path: 'knowledge-window', component: KnowledgeWindowComponent },
  { path: 'diagnosis-triage-tool', component: DiagnosisTriageToolComponent },
  {
    path: 'symptom-details',
    children: [
      {
        path: ':chunkid',
        component: SymptomDetailsComponent
      }
    ]
  },
  {
    path: 'article-details',
    children: [
      {
        path: ':chunkid',
        component: ArticleDetailsComponent
      }
    ]
  },

  { path: '', redirectTo: '/suggest-diagnosis', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule { }

export const routedComponents = [AppComponent];

// imports: [RouterModule.forRoot(routes, { useHash: true })]
