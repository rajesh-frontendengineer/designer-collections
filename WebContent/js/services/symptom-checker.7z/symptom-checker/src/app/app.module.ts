import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, JsonpModule, Jsonp, Response } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { User } from './data-models/suggest-form.interface';
import { AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import { SuggestDiagnosisComponent } from './suggest-diagnosis/suggest-diagnosis.component';
import { DiagnosisResultsComponent } from './diagnosis-results/diagnosis-results.component';
import { SymptomDisplayDirective } from './diagnosis-results/diagnosis-filter.directive';

import { SymptomDetailsComponent } from './symptom-details/symptom-details.component';
import { DetailsEventsDirective } from './symptom-details/details.events.directive';

import { SuggestDiagnosisService } from './services/suggest-diagnosis.service';
import { DiagnosisResultsResolver } from './resolvers/diagnosis-results-resolver';
import { DiagnosisTriageToolComponent } from './diagnosis-triage-tool/diagnosis-triage-tool.component';
import { SymptomDetailsService } from './services/symptom-details-service';
import { StorageService } from './services/storage.service';
import { SymptomTrailDetailsComponent } from './symptom-trial-details/symptom-trail-details.component';



// 3rd Party Modules
import { NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
// import { TagInputModule } from 'ngx-chips';
// import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
// import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ArticleDetailsComponent } from './article-details/article-details.component';
import { KnowledgeWindowComponent } from './knowledge-window/knowledge-window.component';
import { SafePipe } from './common/safe-pipe';
import { ProviderFinderComponent } from './provider-finder/provider-finder.component';
import { ArticleTrailDetailsComponent } from './article-trail-details/article-trail-details.component';


// TagInputModule.withDefaults({
//   tagInput: {
//       placeholder: 'Add a new tag',
//       // add here other default values for tag-input
//   },
//   dropdown: {
//       displayBy: 'my-display-value',
//       // add here other default values for tag-input-dropdown
//   }
// });

@NgModule({
  declarations: [
    AppComponent,
    SuggestDiagnosisComponent,
    DiagnosisResultsComponent,
    DiagnosisTriageToolComponent,
    SymptomDisplayDirective,
    SymptomDetailsComponent,
    DetailsEventsDirective,
    ArticleDetailsComponent,
    KnowledgeWindowComponent,
    SafePipe,
    ProviderFinderComponent,
    SymptomTrailDetailsComponent,
    ArticleTrailDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    JsonpModule,
    // TagInputModule,
    BrowserAnimationsModule,
    // TypeaheadModule.forRoot(),
    // AccordionModule.forRoot(),
    NgbTypeaheadModule.forRoot()
  ],
  providers: [
    SuggestDiagnosisService,
    DiagnosisResultsResolver,
    SymptomDetailsService,
    StorageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
