import { Component, Renderer2, OnInit, AfterViewInit, Inject, ViewEncapsulation, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot,
  RouterStateSnapshot, RouterState } from '@angular/router';
import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';

import { SymptomDetailsService } from './../services/symptom-details-service';


@Component({
  selector: 'app-article-details',
  templateUrl: './article-details.component.html',
  styleUrls: ['./article-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ArticleDetailsComponent implements OnInit, AfterViewInit {
  CurrentElement: ElementRef;
  renderer2: Renderer2;
  loadingResults: boolean;
  private articleDetails: any;
  constructor(
    private ActRoute: ActivatedRoute,
    private router: Router,
    private SymptomDetailsService: SymptomDetailsService,
    private sanitizer: DomSanitizer,
    el: ElementRef,
    @Inject(DOCUMENT) private document: any,
    renderer: Renderer2
  ) {
    this.loadingResults = true;
    this.renderer2 = renderer;
    this.CurrentElement = el;
    this.ActRoute.params
    .map(params => params)
    .subscribe((data) => {
      if (data.chunkid) {

        console.log(data.chunkid);

        this.SymptomDetailsService.getArticleDetails(data.chunkid).subscribe(res => {
          this.loadingResults = false;
          // console.log(res._body);
          this.articleDetails = this.sanitizer.bypassSecurityTrustHtml(res._body);
          // console.log(this.symptomDetails);
        });
      }
    });

   }

  ngOnInit() {
    // console.log(this.document.querySelectorAll('div'));
  }

  ngAfterViewInit() {
    console.log(this.CurrentElement.nativeElement.querySelectorAll('a'));
    console.log(this.document.querySelectorAll('.articleDetailClick'));
    setTimeout(() => {
        console.log(this.document.querySelectorAll('.articleDetailClick'));
        console.log(this.router);

        this.document.querySelectorAll('.articleDetailClick').forEach( ( item ) => {
            console.log(item.id);

                  this.renderer2.listen(item, 'click', (event) => {
                    // Do something with 'event'
                    event.preventDefault();
                    console.log('item-clicked');
                    this.router.navigate(['/symptom-details/' + item.id]);
                  });
                  // item.addEventListener('click', function(event) {
                  //         event.preventDefault();
                  //         console.log('item-clicked');
                  //         console.log(this.router);
                  //         // this.router.navigate(['/suggest-diagnosis']);
                  //         this.onsubmit();
                  // });
                });
        // this.renderer.listen(this.CurrentElement.nativeElement.querySelectorAll('.articleDetailClick')[1], 'click', (event) => { this.handleClick(event); });

    }, 1000);
  }

  onsubmit() {
    console.log(this.router);
  }
}
