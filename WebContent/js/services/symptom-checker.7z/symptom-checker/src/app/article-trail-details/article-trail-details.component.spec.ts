import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleTrailDetailsComponent } from './article-trail-details.component';

describe('ArticleTrailDetailsComponent', () => {
  let component: ArticleTrailDetailsComponent;
  let fixture: ComponentFixture<ArticleTrailDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleTrailDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleTrailDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
