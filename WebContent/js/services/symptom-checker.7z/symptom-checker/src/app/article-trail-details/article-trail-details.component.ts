import { Component, EventEmitter, Input, Output, OnChanges, HostListener, HostBinding, SimpleChanges, Renderer2, OnInit, AfterViewInit, Inject, ViewEncapsulation, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot,
  RouterStateSnapshot, RouterState } from '@angular/router';
import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';

import { SymptomDetailsService } from './../services/symptom-details-service';

@Component({
  selector: 'app-article-trail-details',
  templateUrl: './article-trail-details.component.html',
  styleUrls: ['./article-trail-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ArticleTrailDetailsComponent implements OnInit, AfterViewInit {
  private _ArticleDetails = '';
  renderer2: Renderer2;
  // @Output() onClickArticleDetails = new EventEmitter<String>();

  @Input()
  set ArticleDetails(ArticleDetails: any){
      this._ArticleDetails = ArticleDetails;
  }
  get ArticleDetails(): any{
    return this._ArticleDetails;
  }

  constructor(
      private ActRoute: ActivatedRoute,
      private router: Router,
      private SymptomDetailsService: SymptomDetailsService,
      private sanitizer: DomSanitizer,
      el: ElementRef,
      @Inject(DOCUMENT) private document: any,
      renderer: Renderer2
    ) {
      this.renderer2 = renderer;
    }

  ngOnInit() {

  }

   ngAfterViewInit() {
      // console.log(this.document.querySelectorAll('.articleSearchClick'));
      // setTimeout(() => {
      //     console.log(this.document.querySelectorAll('.articleSearchClick'));
      //     this.document.querySelectorAll('.articleSearchClick').forEach( ( item ) => {
      //         console.log(item.id);
      //               this.renderer2.listen(item, 'click', (event) => {
      //                 // Do something with 'event'
      //                 event.preventDefault();
      //                 console.log('item-clicked');
      //                 // this.router.navigate(['/article-details/' + item.id]);
      //                 this.onArticleDetails(item.id);
      //               });
      //               // item.addEventListener('click', function(event) {
      //               //         event.preventDefault();
      //               //         console.log('item-clicked');
      //               //         console.log(this.router);
      //               //         // this.router.navigate(['/suggest-diagnosis']);
      //               //         this.onsubmit();
      //               // });
      //             });
      //     // this.renderer.listen(this.CurrentElement.nativeElement.querySelectorAll('.articleDetailClick')[1], 'click', (event) => { this.handleClick(event); });
      // }, 1000);
    }
}
