
export const SymptomsCheckerConstants = {
    SERVICE_URL : 'https://symptomchecker.isabelhealthcare.com',
    LoginCred : 'action=login&id=2682&password=15abel2017!',
    FormGroup_SERVICE : {
        'AgeGroupAPI': '/suggest_diagnoses_advanced/get_service_age_groups?language=english&web_service=json&callback=JSONP_CALLBACK',
        'RegionGroupAPI': '/suggest_diagnoses_advanced/get_service_regions?language=english&web_service=json&callback=JSONP_CALLBACK',
        'PregnanciesAPI': '/suggest_diagnoses_advanced/get_service_pregnancies?language=english&web_service=json&callback=JSONP_CALLBACK'
    },

    SUGGEST_SERVICE : {
        DiagnosisAPI : '/private/emr_diagnosis.jsp?searchType=0&specialties=28&suggest=Suggest+Differential+Diagnosis&web_service=json&flag=sortbyRW_advanced&callback=JSONP_CALLBACK&',
    },
    TRIAGE_TOOL_SERVICE : {
        TriageToolAPI : '/suggest_diagnoses_advanced/triage_tool_bb?'
    },

    // Symptom Details Services
    EBSCO_Services: {
        SymptomDetailsAPI : 'https://api.bcbsal.org/HealthHandbook/SymptomDetail?',
        ArticleDetailsAPI  : 'https://api.bcbsal.org/HealthHandbook/ArticleDetail?db=hlt',
        ContentSearchAPI : 'https://api.bcbsal.org/HealthHandbook/ContentSearch?db=hlt&'
    },

    PFR_Services: {
        SearchService : 'https://apitest.bcbsal.org/providerfinder/search?indent=true&apikey=444-0d1b828f-d275-4968-8d1c-c3515cee626c&wt=json'
    }
};



