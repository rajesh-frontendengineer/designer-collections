
export interface User {
    name: string;
    account: {
      email: string;
      confirm: string;
    };
  }

export interface Heroes {
    name: string;
    phone: Number;
  }

 export interface SuggestFormData {
  ageGroup: String;
  genderCheck: String;
  regionGroup: String;
  symptoms: String;
}
