import { Directive, ElementRef, Input, HostListener, OnChanges, HostBinding, SimpleChanges  } from '@angular/core';


@Directive({ selector: '[appSymptomDisplay]' })
export class SymptomDisplayDirective implements OnChanges {

    CurrentElement: ElementRef;

    @Input('symptomDisplay') symptomDisplay: string;
    @HostBinding('style.display')
    @Input() FlexDisplay: string;
    // @HostBinding('class')
    // @Input() classes: string;
    // @HostBinding('symptomDisplay')
    // @Input() symptomDisplayBinding: string;

    @HostListener('mouseenter') onMouseEnter() {
       console.log(this.symptomDisplay);

       // this.FlexDisplay = 'none';
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['symptomDisplay'].currentValue === 'top10') {
            if (this.CurrentElement.nativeElement.classList.value.indexOf('top10') > -1) {
                this.FlexDisplay = 'flex';
            }else {
                this.FlexDisplay = 'none';
            }
        }else if (changes['symptomDisplay'].currentValue === 'common') {
            if (this.CurrentElement.nativeElement.classList.value.indexOf('common') > -1) {
                this.FlexDisplay = 'flex';
            }else {
                this.FlexDisplay = 'none';
            }
        }else if (changes['symptomDisplay'].currentValue === 'redflags') {
            if (this.CurrentElement.nativeElement.classList.value.indexOf('red-flag') > -1) {
                this.FlexDisplay = 'flex';
            }else {
                this.FlexDisplay = 'none';
            }
        }else if (changes['symptomDisplay'].currentValue === 'showall') {
            this.FlexDisplay = 'flex';
        }
    }

    constructor(el: ElementRef) {
        this.CurrentElement = el;
    }
}
