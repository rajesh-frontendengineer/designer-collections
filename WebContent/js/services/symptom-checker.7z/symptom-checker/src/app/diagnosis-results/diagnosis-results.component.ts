import { Component, EventEmitter, OnInit, ViewEncapsulation, Input, Output, OnChanges, HostListener, HostBinding, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { URLSearchParams } from '@angular/http';
import { NgFor } from '@angular/common';
import { parse } from 'url';


@Component({
  selector: 'app-diagnosis-results',
  templateUrl: './diagnosis-results.component.html',
  styleUrls: ['./diagnosis-results.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DiagnosisResultsComponent implements OnInit, OnChanges {
  private _diagnosis = '';
  filterSymptoms: String;
  switchFilterActive: Array<Boolean>;
  @Output() onClickSymptomDetails = new EventEmitter<Object>();
  @Output() onClickFilerResults = new EventEmitter<Object>();

  @Input()
  set diagnosis(diagnosis: any){
      this._diagnosis = diagnosis.sort(function(a, b) {
        return parseFloat(a.weightage) < parseFloat(b.weightage) ? 1 : -1;
      });
  }

  get diagnosis(): any{
    return this._diagnosis;
  }

  @Input()  loadingStyle: any ;
  @Input()  loadingSpinnerStyle: any ;
  @HostBinding('attr.role') role = 'admin';
  @HostListener('click') onClick() {
   // this.role=this.role=='admin'?'guest':'admin';
  }


  public onResize() {
    console.log('windowresized');
  }
  constructor(private router: Router) {
    this.diagnosis = [];
    this.filterSymptoms = 'top10';
    this.switchFilterActive = [true, false, false, false];
   }

  ngOnInit() {
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
  }

  public displaySymptoms(filterActive: number, value: string): void {
    this.filterSymptoms = value;
    this.switchFilterActive = [false, false, false, false];
    this.switchFilterActive[filterActive] = true;
    this.onClickFilerResults.emit(value);
    // console.log(value);
  }

  public onKnowledgeWindow(value: string): void {
      const kURL = parse(value, true);
      this.router.navigate(['/knowledge-window'], { queryParams: kURL.query });
      console.log(kURL);
      // this.router.navigate(['/diagnosis-triage-tool' + encodeURIComponent(value)]);

    // console.log(value);
  }

  onSymptomDetails(chunkID: String, symptomName: String) {
    const symptomDetails = {
      'chunkID': chunkID,
      'symptomName': symptomName
    };
    this.onClickSymptomDetails.emit(symptomDetails);
  }

}
// https://symptomchecker.isabelhealthcare.com/search_knowledge_advanced/knowledge_window?
// category_id=3423&
// category_type=standalone&
// diagnoses_name=Tooth Abscess&
// diagnoses_sub=3423&
// age_id=4&
// sex=female&
// pregnancy=seen&
// region=6&
// text=face ache&
// specialty_id=28&

// sessionId=fc52da8b1c5959a977460e4b5d1e0758&


// userid=2682&

// emr=true