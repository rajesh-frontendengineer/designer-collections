import { Component, OnInit, Inject, ViewChild, AfterViewInit, ElementRef, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, FormControl } from '@angular/forms';
import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot,
  RouterStateSnapshot, RouterState } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
import { triageToolFormConst } from './dianosis-triage-tool-constant';
import { SuggestDiagnosisService } from './../services/suggest-diagnosis.service';
import * as devguage from 'C:/bcbsapps/symptom-checker/node_modules/canvas-gauges/gauge.min';
import * as Swiper from 'C:/BreadCrumb/symptom-checker/node_modules/swiper/dist/js/swiper';

@Component({
  selector: 'app-diagnosis-triage-tool',
  templateUrl: './diagnosis-triage-tool.component.html',
  styleUrls: ['./diagnosis-triage-tool.component.scss'],
   encapsulation: ViewEncapsulation.None
})
export class DiagnosisTriageToolComponent implements OnInit, AfterViewInit, OnDestroy {
  diagnosisMeter: any;
  triageQueryParams: any;
  returnToDiagnosisResults: any;
  private triageToolFormConst: any;
  triageToolForm: FormGroup;
  mySwiper: any;
  isPrevValid: Boolean;
  isNextValid: Boolean;
  @ViewChild('whereNow', {read: ElementRef}) whereNowId: ElementRef;
  // console.log(whereNowId.getElementById("myId"));
  public isQOpen: Array<Boolean>;

  Question01: String;
  Question02: String;
  Question03: String;
  Question04: String;
  Question05: String;
  Question06: String;
  Question07: String;

  Question01Control: AbstractControl;
  Question02Control: AbstractControl;
  Question03Control: AbstractControl;
  Question04Control: AbstractControl;
  Question05Control: AbstractControl;
  Question06Control: AbstractControl;
  Question07Control: AbstractControl;
  constructor(
    private fb: FormBuilder,
    private ActRoute: ActivatedRoute,
    private router: Router,
    private SuggestDiagnosisService: SuggestDiagnosisService
  ) {
    ActRoute.queryParams.subscribe((result => {
      this.triageQueryParams = result;
      this.returnToDiagnosisResults = '/suggest-diagnosis/' + result.age + '/' + result.sex + '/' + result.region + '/' + result.pregnancy + '/' + result.text;
      console.log(result);
      console.log(ActRoute);
    }));
    this.isQOpen = [true, false, false, false, false, false, false];
    this.Question01 = '';
    this.Question02 = '';
    this.Question03 = '';
    this.Question04 = '';
    this.Question05 = '';
    this.Question06 = '';
    this.Question07 = '';

    // console.log(ActivatedRouteSnapshot.queryParams);
    // ActRoute.data.subscribe((results => {
    //   console.log(RoutSnapShot);
    // }));
   }

  ngOnInit() {
    this.triageToolFormConst = triageToolFormConst;
    this.buildForm();
    this.isPrevValid = false;
    this.isNextValid = true;
    // this.buildSwiper();
  }

  ngAfterViewInit() {
    // contentChild is set after the content has been initialized
    this.buildSwiper();
    this.buildDiagnosisMeter();
  }

  ngOnDestroy() {
    console.log('destroy');
    console.log(this.mySwiper);
    // if (this.mySwiper.length === 2) {
    //   this.mySwiper.destroy(true, true);
    // }
    console.log(this.mySwiper);
  }

  NextActiveIndex(event): void {
    console.log(this.mySwiper.activeIndex + 1);
    if (this.mySwiper.activeIndex === 6 || this.mySwiper.activeIndex === 7) {
      this.isNextValid = false;
      this.isPrevValid = true;
    }else {
      this.isNextValid = true;
      this.isPrevValid = true;
      const Qno = 'Question0' + (this.mySwiper.activeIndex + 1);
      if (this.triageToolForm.value[Qno] !== '') {
        if (this.mySwiper.length === 2) {
          this.mySwiper = this.mySwiper[0];
        }
        this.mySwiper.slideNext(1000, true);
      }
    }
  }
  PrevActiveIndex(e): void {
    console.log(this.mySwiper.activeIndex);
    if (this.mySwiper.activeIndex === 0) {
      this.isPrevValid = false;
    }else {
      this.isNextValid = true;
      this.isPrevValid = true;
      if (this.mySwiper.length === 2) {
        this.mySwiper = this.mySwiper[0];
      }
      this.mySwiper.slidePrev(1000, true);
    }
  }

  SubmitWhereNowForm(e): void {
    this.mySwiper.slideNext(1000, true);
  }
  buildSwiper(): void {
    this.mySwiper = new Swiper('.swiper-container', {
      el: '.swiper-container',
      initialSlide: 0,
      spaceBetween: 50,
      centeredSlides: true,
      allowTouchMove: false,
      // grabCursor: true,
      scrollbar: {
        el: '.swiper-scrollbar',
      },
      keyboard: {
        enabled: true,
      },
      pagination: {
        el: '.swiper-pagination',
        type: 'progressbar'
        // clickable: true
      }
    });
  }

  buildForm(): void {
    this.triageToolForm = this.fb.group({
        'Question01':  [this.Question01, Validators.required],
        'Question02':  [this.Question02, Validators.required],
        'Question03':  [this.Question03, Validators.required],
        'Question04':  [this.Question04, Validators.required],
        'Question05':  [this.Question05, Validators.required],
        'Question06':  [this.Question06, Validators.required],
        'Question07':  [this.Question07, Validators.required],
    });
    this.Question01Control = this.triageToolForm.get('Question01');
    this.Question02Control = this.triageToolForm.get('Question02');
    this.Question03Control = this.triageToolForm.get('Question03');
    this.Question04Control = this.triageToolForm.get('Question04');
    this.Question05Control = this.triageToolForm.get('Question05');
    this.Question06Control = this.triageToolForm.get('Question06');
    this.Question07Control = this.triageToolForm.get('Question07');
  }
  buildDiagnosisMeter(): void {
    this.diagnosisMeter = new devguage.RadialGauge({
      renderTo: 'diagonsisGuage',
      width: 300,
      height: 300,
      minValue: 0,
      startAngle: 90,
      ticksAngle: 180,
      valueBox: false,
      maxValue: 150,
      majorTicks: [],
      minorTicks: 2,
      strokeTicks: true,
      highlights: [
        {
          'from': 0,
          'to': 18,
          'color': 'rgb(161,191,10)'
        },
        {
          'from': 19,
          'to': 36,
          'color': 'rgb(161,191,10)'
        },
        {
          'from': 37,
          'to': 54,
          'color': 'rgb(161,191,10)'
        },
        {
            'from': 55,
            'to': 72,
            'color': 'rgb(255,191,56)'
        },
        {
            'from': 73,
            'to': 90,
            'color': 'rgb(255,191,56)'
        },
        {
          'from': 91,
          'to': 108,
          'color': 'rgb(255,191,56)'
        },
        {
            'from': 109,
            'to': 130,
            'color': 'rgb(214,61,71)'
        },
        {
          'from': 131,
          'to': 150,
          'color': 'rgb(214,61,71)'
      }
      ],
      colorPlate: '#fff',
      colorNumbers: '#fff',
      borderShadowWidth: 0,
      borders: false,
      needleType: 'arrow',
      needleWidth: 2,
      needleCircleSize: 7,
      needleCircleOuter: true,
      needleCircleInner: false,
      animationDuration: 5000,
      animationRule: 'linear'
  }).draw();
  }

  onSubmit() {
    console.log(this.triageToolForm.value, this.triageQueryParams);
    this.SuggestDiagnosisService.TriageTool(this.triageToolForm.value, this.triageQueryParams).subscribe(res => {
      const score = parseInt(res.triage_score, 10);
      if (score !== NaN) {
        console.log(res.triage_score);
        this.mySwiper.slideNext(1000, true);
        this.diagnosisMeter.value = res.triage_score;
      }
      console.log(res.triage_score);
    });
  }
  accordionGrpReset(QNumber) {
    this.isQOpen = [false, false, false, false, false, false, false];
    this.isQOpen[QNumber] = false;
    this.isQOpen[QNumber + 1] = true;
  }

  // getSuggestDiagnosisResults(ageGroup, genderCheck, regionGroup, symptoms) {
  //   this.SuggestDiagnosisService.SuggestDifferentialDiagnosis(ageGroup, genderCheck, regionGroup, symptoms).subscribe(res => {
  //     console.log(res);
  //   });
  // }


}


// RadialGauge(
//   {
//     renderTo: 'diagonsisGuage',
//     width: 300,
//     height: 300,
//     units: 'Where to now ?',
//     startAngle: 90,
//     maxValue: 150,
//     ticksAngle: 180,
//     minValue: 0,
//     majorTicks: [
//     '0', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100', '110', '120', '130', '140', '150'
//     ],
//     minorTicks: 3,
//     strokeTicks: true,
//     highlights: [
//         {
//             'from': 0,
//             'to': 34,
//             'color': 'rgba(12, 246, 37,1)'
//         },
//         {
//             'from': 35,
//             'to': 79,
//             'color': 'rgba(246, 238, 13, 0.73)'
//         },
//         {
//             'from': 70,
//             'to': 79,
//             'color': 'rgba(246, 26, 13, 0.73)'
//         },
//         {
//             'from': 80,
//             'to': 150,
//             'color': 'rgba(255, 0, 0, 1)'
//         }
//     ],
//     colorPlate: '#fff',
//     borderShadowWidth: 0,
//     borders: true,
//     needleType: 'arrow',
//     needleWidth: 2,
//     needleCircleSize: 7,
//     needleCircleOuter: true,
//     needleCircleInner: false,
//     animationDuration: 5000,
//     animationRule: 'linear'
// }).draw();
