export let triageToolFormConst = [
    {
        FormName : 'Question01',
        ControlName : 'QuestionControl01',
        Question: 'How quickly did your symptoms develop?',
        Answers : [
            {key: 'Over hours', value: '1'},
            {key: 'Over days', value: '2'},
            {key: 'Over weeks', value: '3'},
            {key: 'Over months', value: '4'}
        ],
        isOpen: 'true'
    },
    {
        FormName : 'Question02',
        ControlName : 'QuestionControl02',
        Question: 'How long have you had your symptoms?',
        Answers : [
            {key: '1-6 days', value: '1'},
            {key: 'Weeks', value: '2'},
            {key: 'Months', value: '3'}
        ],
        isOpen: 'false'
    },
    {
        FormName : 'Question03',
        ControlName : 'QuestionControl03',
        Question: 'How have your symptoms changed over the last few hours/days?',
        Answers : [
            {key: 'Better', value: '1'},
            {key: 'Same', value: '2'},
            {key: 'Worse', value: '3'}
        ],
        isOpen: 'false'
    },
    {
        FormName : 'Question04',
        ControlName : 'QuestionControl04',
        Question: 'How much pain or discomfort are you in?',
        Answers : [
            {key: 'None', value: '1'},
            {key: 'Mild Discomfort', value: '2'},
            {key: 'Very Uncomfortable', value: '3'},
            {key: 'Unbearable', value: '4'}
        ],
        isOpen: 'false'
    },
    {
        FormName : 'Question05',
        ControlName : 'QuestionControl05',
        Question: 'How are your symptoms affecting your daily activities?',
        Answers : [
            {key: 'No affect', value: '1'},
            {key: 'Struggling', value: '2'},
            {key: 'Unable', value: '3'}
        ],
        isOpen: 'false'
    },
    {
        FormName : 'Question06',
        ControlName : 'QuestionControl06',
        Question: 'Do you feel better after taking medication?',
        Answers : [
            {key: 'Not taking any', value: '1'},
            {key: 'Yes', value: '2'},
            {key: 'No', value: '3'}
        ],
        isOpen: 'false'
    },
    {
        FormName : 'Question07',
        ControlName : 'QuestionControl07',
        Question: 'Do you have any other serious, long term conditions such as diabetes, cancer, heart condition etc?',
        Answers : [
            {key: 'No', value: '1'},
            {key: 'Yes', value: '2'}
        ],
        isOpen: 'false'
    }
];
