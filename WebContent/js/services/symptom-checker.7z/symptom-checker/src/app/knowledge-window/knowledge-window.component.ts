import { Component, OnInit, Inject, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, FormControl } from '@angular/forms';
import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot,
  RouterStateSnapshot, RouterState } from '@angular/router';

import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/from';
import 'rxjs/operator/map';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';

@Component({
  selector: 'app-knowledge-window',
  templateUrl: './knowledge-window.component.html',
  styleUrls: ['./knowledge-window.component.scss']
})
export class KnowledgeWindowComponent implements OnInit {
  knowledgeWindowQueryParams: any;
  knowledgeURL: String;

  constructor(private ActRoute: ActivatedRoute,
    private router: Router) {

      ActRoute.queryParams.subscribe((result => {
        this.knowledgeWindowQueryParams = result;
        // this.knowledgeURL = 'https://www.google.com/';
         this.knowledgeURL = 'https://symptomchecker.isabelhealthcare.com/search_knowledge_advanced/knowledge_window?category_id=1043&category_type=standalone&diagnoses_name=Bell%27s+Palsy&diagnoses_sub=1043&age_id=4&sex=female&pregnancy=seen&region=5&text=face+droop+unilateral&specialty_id=28&sessionId=fc52da8b1c5959a977460e4b5d1e0758&userid=2682&emr=true';
       // this.knowledgeURL = this.generateKWUrl(result);
        // console.log(result);
      }));

    }

  ngOnInit() {
  }
  generateKWUrl(QParams) {
    console.log(QParams);
    const whereNowURLTree = 'https://symptomchecker.isabelhealthcare.com/search_knowledge_advanced/knowledge_window?';
    Observable.of(QParams)
    .map((e) => {
      console.log(e.response);
    });
    for (const prop of QParams) {
      console.log(typeof(QParams));
      console.log(prop);
    }

    return whereNowURLTree;
  }

}

// "category_id=2381&category_type=standalone&diagnoses_name=Rabies &diagnoses_sub=2381&age_id=10&sex=female&pregnancy=N&region=5&text=fear of air&specialty_id=28&sessionId=fc52da8b1c5959a977460e4b5d1e0758&userid=2682&emr=true"