import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-finder',
  templateUrl: './provider-finder.component.html',
  styleUrls: ['./provider-finder.component.scss']
})
export class ProviderFinderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
