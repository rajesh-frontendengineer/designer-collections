import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { SuggestDiagnosisService } from './../services/suggest-diagnosis.service';


@Injectable()
export class DiagnosisResultsResolver implements Resolve<any> {
    constructor(
        private SuggestDiagnosisService: SuggestDiagnosisService,
    ) { }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
        console.log( route.params );
        return this.SuggestDiagnosisService.SuggestDifferentialDiagnosis(route.params.age , route.params.gender, route.params.region, route.params.symptoms, route.params.pregnant, 0);
    }

}
