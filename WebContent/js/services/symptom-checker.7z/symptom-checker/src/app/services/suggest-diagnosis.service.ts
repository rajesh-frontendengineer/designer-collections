import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Jsonp, Response, Headers, RequestOptions, Http } from '@angular/http';
import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';

import { SymptomsCheckerConstants } from './../common/symptomCheckerConstants';

import 'rxjs/operator/map';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';


@Injectable()
export class SuggestDiagnosisService {

    public pendingRequests: number;
    public showLoading: Boolean = false;

    SERVICE_URL = SymptomsCheckerConstants.SERVICE_URL;
    LOGIN_CRED = SymptomsCheckerConstants.LoginCred;
    SuggestDifferentialDiagnosisEndPoint = this.SERVICE_URL + SymptomsCheckerConstants.SUGGEST_SERVICE.DiagnosisAPI + this.LOGIN_CRED ;
    TriageToollDiagnosisEndPoint = this.SERVICE_URL + SymptomsCheckerConstants.TRIAGE_TOOL_SERVICE.TriageToolAPI + this.LOGIN_CRED ;

    constructor(private jsonp: Jsonp, private http: Http, @Inject(DOCUMENT) private document: any) {
        this.pendingRequests = 0;
    }

    getSymptomSuggestions(searchTerm: any): Observable<any> {
        const apiURL = 'http://10.64.85.177:8983/solr/symptomChecker/select?wt=json&indent=true&suggest.build=true&suggest.dictionary=SymptomSuggester&q=' + searchTerm;
        return this.http.get(apiURL)
        .map((response: Response) => {
            return response.json().suggest.SymptomSuggester[searchTerm].suggestions;
        });
    }

    getAgeGroup(): Observable<any> {
        const apiURL = this.SERVICE_URL + SymptomsCheckerConstants.FormGroup_SERVICE.AgeGroupAPI ;
        return this.jsonp.request(apiURL)
        .map((response: Response) => {
            console.log(response);
            return response.json().age_groups;
        });
    }

    getRegions(): Observable<any> {
        const apiURL = this.SERVICE_URL + SymptomsCheckerConstants.FormGroup_SERVICE.RegionGroupAPI ;
        return this.jsonp.request(apiURL)
        .map((response: Response) => response.json().travel_history);
    }

    getPregnancies(): Observable<any> {
        const apiURL = this.SERVICE_URL + SymptomsCheckerConstants.FormGroup_SERVICE.PregnanciesAPI ;
        return this.jsonp.request(apiURL)
        .map((response: Response) => response.json());
    }

    SuggestDifferentialDiagnosis(ageGroup: Number, genderCheck: String, regionGroup: Number, pregnant: Number, symptoms: String, pendingRequests: Number): Observable<any> {
        console.log(ageGroup, genderCheck, regionGroup, pregnant, symptoms);
        const apiURL = this.SuggestDifferentialDiagnosisEndPoint + this.BuildQuery(ageGroup, genderCheck, regionGroup, pregnant, symptoms);
        return this.intercept(this.jsonp.request(apiURL), pendingRequests);
    }

    BuildQuery(ageGroup, genderCheck, regionGroup, pregnant, symptoms) {
        return '&sex=' + genderCheck + '&pregnant=' + pregnant + '&region=' + regionGroup + '&querytext=' + symptoms + '&dob=' + ageGroup;
    }

    TriageTool(triageToolForm: Object, triageQueryParams: Object): Observable<any> {
        console.log(triageToolForm, triageQueryParams);
        const apiURL = this.TriageToollDiagnosisEndPoint + this.BuildTraigeToolQuery(triageToolForm, triageQueryParams);
        return this.jsonp.request(apiURL)
        .map((response: Response) => response.json().where_to_now);
    }

    BuildTraigeToolQuery(triageToolForm, triageQueryParams) {
        return '&dx=' + triageQueryParams.dx + '&sex=' + triageQueryParams.sex + '&age=' + triageQueryParams.age +
               '&pregnancy=' + triageQueryParams.pregnancy + '&region=' + triageQueryParams.region +
               '&text=' + triageQueryParams.text + '&Q1=' + triageToolForm.Question01 + '&Q2=' + triageToolForm.Question01 +
               '&Q3=' + triageToolForm.Question03 + '&Q4=' + triageToolForm.Question04 + '&Q5=' + triageToolForm.Question05 +
               '&Q6=' + triageToolForm.Question06 + '&Q7=' + triageToolForm.Question07 + '&web_service=json&callback=JSONP_CALLBACK';
    }

    intercept(observable: Observable<Response>, pendingRequest: Number): Observable<Response> {
        const loadingStyle = {
             'background-color': 'rgba(255, 255, 255, 0.5)',
             display: 'none',
             height: '500px',
             width: '980px',
             position: 'absolute',
             'z-index': 2000,
             'text-align': 'center'
        };
        const loadingSpinnerStyle = {
            'text-align': 'center',
            display: 'inline-block',
            background: 'white',
            border: '1px solid black',
            padding: '10px'
        };
        console.log('PendingReq' + pendingRequest);
        if (pendingRequest > 0) {
            this.turnOnModal();
            console.log('In the intercept routine..');
        }
        return observable
          .catch((err, caught) => caught)
          .map((response: Response) => {
            // this.turnOnModal();
            return response.json();
          }, (err: any) => {
            console.log('Caught error: ' + err);
          })
          .finally(() => {
            // const timer = Observable.timer(1000);
            // let timer = Observable.timer(1000);
            // timer.subscribe(t => {
            //   this.turnOffModal();
            // });
            if (pendingRequest > 0) {
                console.log('Finally.. delaying, though.');
                setTimeout(() => {
                    this.turnOffModal();
                });
            }
          });
    }

    private turnOnModal() {
        if (!this.showLoading) {
            this.showLoading = true;
            const resultsContainer = this.document.querySelector('.overlay-parent');
            console.log(resultsContainer.clientWidth);
            console.log(resultsContainer.clientHeight);
            console.log('Turned on modal');
        }
        this.showLoading = true;
      }

      private turnOffModal() {
        this.pendingRequests--;
        if (this.pendingRequests <= 0) {
          if (this.showLoading) {
            const body = this.document.querySelector('.overlay-parent');
            console.log(body);
          }
          this.showLoading = false;
        }
        console.log('Turned off modal');
      }
}


