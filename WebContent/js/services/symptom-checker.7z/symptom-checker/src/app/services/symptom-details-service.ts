import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { SymptomsCheckerConstants } from './../common/symptomCheckerConstants';

import 'rxjs/operator/map';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';


@Injectable()
export class SymptomDetailsService {

    SymptomDetailsEndPoint = SymptomsCheckerConstants.EBSCO_Services.SymptomDetailsAPI;
    ArticleDetailsEndPoint = SymptomsCheckerConstants.EBSCO_Services.ArticleDetailsAPI;
    ContentSearchDetailsEndPoint = SymptomsCheckerConstants.EBSCO_Services.ContentSearchAPI;
    PFRSearchEnpoint = SymptomsCheckerConstants.PFR_Services.SearchService;

    constructor(
        private http: Http
    ) { }

    getContentSearchDetails(id): Observable<any> {
        const apiURL = this.ContentSearchDetailsEndPoint + 'chunkid=' + id ;
        return this.http.get(apiURL)
        .map((response: Response) => response);

    }
    getSymptomDetails(id): Observable<any> {
        const apiURL = this.SymptomDetailsEndPoint + 'chunkid=' + id ;
        return this.http.get(apiURL)
        .map((response: Response) => response);

    }
    getArticleDetails(id): Observable<any> {
        const apiURL = this.ArticleDetailsEndPoint + '&chunkid=' + id ;
        return this.http.get(apiURL)
        .map((response: Response) => response);
    }
    getSpecialityDoctors(): Observable<any> {
        const query = '&locationsearch=true&key=**&rows=2&location=33.386494%2C-86.77868219999999&radius=50&criteria=%257B!geofilt%257D' +
        '&start=0&boost=recip(geodist(),1,1000,1000)&criteria1=filter(category%3A(%22Doctor%22))%20AND%20filter(specialty%3A(%22General%20Practice%22%20OR%20%22Internal%20Medicine%22))';
        const apiURL = this.PFRSearchEnpoint + query;
        return this.http.get(apiURL)
        .map((response: Response) => response);
    }
}
