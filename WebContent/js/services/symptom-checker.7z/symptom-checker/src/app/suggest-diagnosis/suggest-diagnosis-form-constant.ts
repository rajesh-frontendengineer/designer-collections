export const symptomCheckerFormConst = {
    ageGroups: [
        {
            agegroup_id: '1',
            branch: 'paediatric',
            can_conceive: 'false',
            name: 'newborn',
            ordinal: '0',
            yr_from: '0',
            yr_to: '28 days'
        },
        {
            agegroup_id: '2',
            branch: 'paediatric',
            can_conceive: 'false',
            name: 'infant',
            ordinal: '2',
            yr_from: '29 days',
            yr_to: '1 year'
        },
        {
            agegroup_id: '3',
            branch: 'paediatric',
            can_conceive: 'false',
            name: 'younger child',
            ordinal: '4',
            yr_from: '1',
            yr_to: '5 years'
        },
        {
            agegroup_id: '10',
            branch: 'paediatric',
            can_conceive: 'false',
            name: 'older child',
            ordinal: '5',
            yr_from: '6',
            yr_to: '12 years'
        },
        {
            agegroup_id: '4',
            branch: 'paediatric',
            can_conceive: 'false',
            name: 'adolescent',
            ordinal: '6',
            yr_from: '13',
            yr_to: '16 years'
        },
        {
            agegroup_id: '7',
            branch: 'paediatric',
            can_conceive: 'false',
            name: 'young adult',
            ordinal: '8',
            yr_from: '17',
            yr_to: '29 years'
        },
        {
            agegroup_id: '5',
            branch: 'adult',
            can_conceive: 'true',
            name: 'young adult',
            ordinal: '10',
            yr_from: '30',
            yr_to: '39 years'
        },
        {
            agegroup_id: '8',
            branch: 'adult',
            can_conceive: 'true',
            name: 'young adult',
            ordinal: '8',
            yr_from: '17',
            yr_to: '49 years'
        },
        {
            agegroup_id: '9',
            branch: 'adult',
            can_conceive: 'tru',
            name: 'adult',
            ordinal: '14',
            yr_from: '50',
            yr_to: '64 years'
        },
        {
            agegroup_id: '6',
            branch: 'adult',
            can_conceive: 'false',
            name: 'senior',
            ordinal: '16',
            yr_from: '65 yrs',
            yr_to: 'over'
        },
    ],
    getAgeGroups: [
        'newborn (0 to 28 days )', 'infant (29 d to 1 yr )', 'younger child (1 to 5 yrs)', 'adolescent (13 to 16 yrs )',
        'adult (30 to 39 yrs )', 'senior (65 yrs to over )', 'young adult (17 to 29 yrs )', 'adult (40 to 49 yrs)', 'adult (50 to 64 yrs )',
        'older child (6 to 12 yrs)'
    ],
    regionGroups: [
        {region_id: '1', region_name: 'Western Europe'},
        {region_id: '2', region_name: 'Eastern Europe'},
        {region_id: '3', region_name: 'Central Africa'},
        {region_id: '4', region_name: 'North Africa'},
        {region_id: '5', region_name: 'East Africa'},
        {region_id: '6', region_name: 'Southern Africa'},
        {region_id: '7', region_name: 'West Africa'},
        {region_id: '8', region_name: 'Southeast Asia'},
        {region_id: '9', region_name: 'East Asia'},
        {region_id: '10', region_name: 'South Asia'},
        {region_id: '11', region_name: 'Caribbean'},
        {region_id: '12', region_name: 'North America'},
        {region_id: '13', region_name: 'Central America'},
        {region_id: '14', region_name: 'South America (trop)'},
        {region_id: '15', region_name: 'South America (temp)'},
        {region_id: '16', region_name: 'Australasia'},
        {region_id: '17', region_name: 'Middle East'}
    ]
};

