import { Component, OnInit, Inject, ViewEncapsulation, ElementRef, AfterViewInit, OnChanges, ViewChild, SimpleChanges, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { FormBuilder, FormGroup, Validators, AbstractControl, FormControl } from '@angular/forms';
import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot, RouterStateSnapshot, RouterState } from '@angular/router';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { SuggestFormData } from './../data-models/suggest-form.interface';
import { symptomCheckerFormConst } from './suggest-diagnosis-form-constant';
import { SuggestDiagnosisService } from './../services/suggest-diagnosis.service';
import { Jsonp, Response, Headers, RequestOptions, Http } from '@angular/http';
import { SymptomDetailsService } from './../services/symptom-details-service';
import * as Swiper from 'C:/BreadCrumb/symptom-checker/node_modules/swiper/dist/js/swiper';
import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';


import 'rxjs/add/observable/of';
import 'rxjs/add/observable/from';
import 'rxjs/operator/map';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';

import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/merge';

@Component({
  selector: 'app-suggest-diagnosis',
  templateUrl: './suggest-diagnosis.component.html',
  styleUrls: ['./suggest-diagnosis.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class SuggestDiagnosisComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  public SuggestFormData: SuggestFormData;
  suggestForm: FormGroup;
  ageGroupControls: AbstractControl;
  genderCheckControls: AbstractControl;
  regionGroupControls: AbstractControl;
  pregnantControls: AbstractControl;

  ageGroup: String;
  ageGroupDisplay: Array<String>;
  ageGroupOptions: Array<Object>;
  genderCheck: String;
  genderDisplay: Object;
  regionGroup: String;
  regionGroupOptions: Array<Object>;
  pregnant: String;
  pregnantDisplay: Array<String>;
  symptoms: Array<String>;
  showSymptomSearch: boolean;

  loadingResults: boolean;
  editBasicDetails: boolean;
  editBasicHeading: boolean;
  loadingStyle: any;
  loadingSpinnerStyle: any;
  private diagnosisResults: Object;
  private triage_tool_QueryParams: Object;
  public pendingRequests: number;
  showPageLevelError: Boolean = false;
  @ViewChild('diagnosisResultsId', {read: ElementRef}) diagnosisResultsId: ElementRef;
  @ViewChild('symtomEnterMobile', {read: ElementRef}) symtomEnterMobile: ElementRef;
  @ViewChild('symptomDetailsId', {read: ElementRef}) symptomDetailsId: ElementRef;
  @ViewChild('articleDetailsId', {read: ElementRef}) articleDetailsId: ElementRef;

  public selected: string;
  public symptomSuggestions: any;
  FormSwiper: any;
  symptomDetails: any;
  articleDetails: any;
  symptomDetailsShow: Boolean;
  activeIndex: Number;
  currentState: Array<String>;
  commonSymptoms: Array<String>;
  states = ['Alabama', 'Alaska', 'American Samoa', 'Arizona', 'Arkansas', 'California', 'Colorado',
  'Connecticut', 'Delaware', 'District Of Columbia', 'Federated States Of Micronesia', 'Florida', 'Georgia',
  'Guam', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine',
  'Marshall Islands', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana',
  'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
  'Northern Mariana Islands', 'Ohio', 'Oklahoma', 'Oregon', 'Palau', 'Pennsylvania', 'Puerto Rico', 'Rhode Island',
  'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virgin Islands', 'Virginia',
  'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];
  search: any;
  searching = false;
  searchFailed = false;
  hideSearchingWhenUnsubscribed = new Observable(() => () => this.searching = false);
  formatter: any;

  constructor(
    private fb: FormBuilder,
    private SuggestDiagnosisService: SuggestDiagnosisService,
    private ActRoute: ActivatedRoute,
    private router: Router,
    @Inject(DOCUMENT) private document: any,
    private http: Http,
    private SymptomDetailsService: SymptomDetailsService,
    private sanitizer: DomSanitizer,
  ) {
    this.currentState = ['BASIC INFO', 'SYMPTOMS', 'POSSIBLE DIAGNOSIS', 'DIAGNOSIS DETAILS', 'ARTICLE DETAILS'];
    this.commonSymptoms = ['Fever', 'Cough', 'Headache', 'weight loss', 'fatigue', 'dizziness', 'chest pain'];
    this.symptoms = [];
    this.showSymptomSearch = false;
    this.loadingResults = false;
    this.pendingRequests = 0;
    this.loadingStyle = {
        'background-color': 'rgba(255, 255, 255, 0.5)',
        display: 'none',
        height: '500px',
        width: '980px',
        position: 'absolute',
        'z-index': 2000,
        'text-align': 'center',
    };
    this.loadingSpinnerStyle = {
        'text-align': 'center',
        display: 'inline-block',
        padding: '80px 10px 10px 10px',
        'margin-top': '30px'
    };
    this.symptomDetailsShow = false;
    if (ActRoute.snapshot.params.age) {
      this.activeIndex = 2;
    }

    this.symptomSuggestions = (text$: Observable<string>) =>
    text$
    .debounceTime(300)
    .distinctUntilChanged()
    .do(() => this.searching = true)
    .switchMap(term =>
      this.getSymptomsAsObservable(term)
        .do(() => this.searchFailed = false)
        .catch(() => {
          this.searchFailed = true;
          return Observable.of([]);
        }))
    .do(() => this.searching = false)
    .merge(this.hideSearchingWhenUnsubscribed);

    this.formatter = (x: {term: string}) => '';

    // this.symptomSuggestions = Observable
    // .create((observer: any) => {
    //   // Runs on every search
    //   observer.next(this.selected);
    // })
    // .mergeMap((token: string) => this.getSymptomsAsObservable(token));

    if (ActRoute.snapshot.params.age && ActRoute.snapshot.params.gender && ActRoute.snapshot.params.region && ActRoute.snapshot.params.symptoms) {
      this.ageGroup = ActRoute.snapshot.params.age;
      this.genderCheck = ActRoute.snapshot.params.gender;
      this.regionGroup = ActRoute.snapshot.params.region;

      this.loadingResults = true;
      this.ActRoute.params
      .map(params => params)
      .subscribe((data) => {
        console.log(this.FormSwiper);
        if (data.age && data.gender && data.region && data.symptoms && data.pregnant) {
          this.ageGroup = data.age;
          this.genderCheck = data.gender;
          this.regionGroup = data.region;
          this.pregnant = data.pregnant;
          this.symptoms = data.symptoms.split(',');
          if (this.pendingRequests > 0) {
            if (this.FormSwiper.activeIndex !== 2) {
              this.showLoadingAndDisplaySearch();
              this.FormSwiper.slideNext(1000, true);
            }
          }
          this.SuggestDiagnosisService.SuggestDifferentialDiagnosis(data.age , data.gender, data.region, data.pregnant, data.symptoms, this.pendingRequests).subscribe(res => {
            this.symptomDetails = undefined;
            this.articleDetails = undefined;
            this.loadingStyle.display = 'none';
            this.pendingRequests++;
            this.editBasicHeading = true;
            this.editBasicDetails = true;
            this.loadingResults = false;
            this.diagnosisResults = res.diagnosis_checklist;
            this.triage_tool_QueryParams = this.parseWhereNowUrl(res.diagnosis_checklist.triage_api_url.slice(43));
            console.log(this.diagnosisResults);
            this.FormSwiper = new Swiper('.swiper-container', {
              initialSlide: 2,
              spaceBetween: 50,
              centeredSlides: true,
              allowTouchMove: false,
              // grabCursor: true,
              scrollbar: {
                el: '.swiper-scrollbar',
              },
              keyboard: {
                enabled: true,
              },
              pagination: {
                el: '.swiper-pagination',
                clickable: true
              },
              on: {
                init: function(){
                  console.log('Second init');
                },
                slideChange: function () {
                  console.log('slide changed 02');
                  console.log(this.slides[this.activeIndex].children[0]);
                  console.dir(this.slides[this.activeIndex].children[0]);
                  if (this.slides[this.activeIndex].length > 0) {
                    const currSlideHeight = this.slides[this.activeIndex].children[0].clientHeight;
                  }

                  // console.log(currSlideHeight);
                  this.$el.css({
                      height: 100 + '%'
                  });
                  // if (this.activeIndex === 1 || this.activeIndex === 2 || this.activeIndex === 3 || this.activeIndex === 4) {
                  //   this.$el.css({
                  //       height: 100 + '%'
                  //   });
                  // }else {
                  //   const currSlideHeight = this.slides[this.activeIndex].children[0].clientHeight;
                  //   console.log(currSlideHeight);
                  //   this.$el.css({
                  //       height: currSlideHeight + 43 + 'px'
                  //   });
                  // }
                }
              }
            });
            // this.FormSwiper.slideTo(1, 1000);
            window.scrollTo(0, this.diagnosisResultsId.nativeElement.offsetTop);
            // this.router.events.subscribe((evt) => {
            //     console.log('naviagtionEnd');
            //     if (!(evt instanceof NavigationEnd)) {
            //         return;
            //     }
            //     window.scrollTo(this.diagnosisResultsId.nativeElement.offsetTop);
            // });
          });
        }
      });
    }else {
        this.ageGroup = '';
        this.genderCheck = '';
        this.regionGroup = '';
        this.pregnant = '0';
        this.loadingResults = false;
        this.editBasicDetails = false;

        // this.FormSwiper = new Swiper('.swiper-container', {
        //   el: '.swiper-container',
        //   initialSlide: 1,
        //   spaceBetween: 50,
        //   centeredSlides: true,
        //   allowTouchMove: false,
        //   // autoHeight: true,
        //   // grabCursor: true,
        //   scrollbar: {
        //     el: '.swiper-scrollbar',
        //   },
        //   keyboard: {
        //     enabled: true,
        //   },
        //   pagination: {
        //     el: '.swiper-pagination',
        //     clickable: true
        //   },
        //   on: {
        //     init: function(){
        //       if (this.FormSwiper) {
        //         console.log(this.FormSwiper[0]);
        //       }
        //       // this.FormSwiper.destroy(true, false);
        //       // console.log('First init' + ' ' + index);
        //     },
        //     slideChange: function () {
        //       console.log('slide changed 01');
        //       const currSlideHeight = this.slides[this.activeIndex].children[0].clientHeight;
        //       console.log(currSlideHeight);
        //       if (this.activeIndex === 1 || this.activeIndex === 2) {
        //         this.$el.css({
        //             height: 100 + '%'
        //         });
        //       }else {
        //         this.$el.css({
        //             height: currSlideHeight + 43 + 'px'
        //         });
        //       }
        //     }
        //   }
        // });
    }

    // const state: RouterState = router.routerState;
    // const snapshot: RouterStateSnapshot = state.snapshot;
    // const root: ActivatedRouteSnapshot = snapshot.root;
    // ActRoute.data.subscribe((results => {
    //   if (results.diagnosiseResults !== undefined) {
    //     this.diagnosisResults = results.diagnosiseResults.diagnosis_checklist;
    //     console.log('data', this.diagnosisResults);
    //     this.triage_tool_QueryParams = this.parseWhereNowUrl(results.diagnosiseResults.diagnosis_checklist.triage_api_url.slice(43));
    //   }else {
    //     this.diagnosisResults = {};
    //   }
    // }));

    // this.parseUrl(this.url2);
    // this.parseUrl(this.url2);


    // router.events.subscribe((val) => {
    //   // see also
    //   // console.log(val);
    //   const state: RouterState = router.routerState;
    //   const snapshot: RouterStateSnapshot = state.snapshot;
    //   const root: ActivatedRouteSnapshot = snapshot.root;
    //   if (val instanceof ResolveEnd) {
    //     console.log(val);
    //     console.log(snapshot);
    //     console.log(root);
    //     // this.diagnosisResults = this.ActRoute.snapshot.data['diagnosiseResults'].diagnosis_checklist;
    //     // console.log(this.diagnosisResults.diagnosis);
    //   }
    // });
  }


  ngAfterViewInit() {
      // this.buildSwiper();
      console.log(this.diagnosisResultsId.nativeElement.offsetTop);
  }

  ngOnDestroy() {
    console.log('destroy');
    console.log(this.FormSwiper);
    // this.FormSwiper.destroy();
    console.log(this.FormSwiper);
  }
  ngOnInit() {
    console.log('ngOnit');
    if (this.activeIndex !== undefined && this.activeIndex === 2) {
      // this.FormSwiper.destroy(true, false);
      this.buildSwiper(2);
      if (this.FormSwiper.length === 2) {
        this.FormSwiper = this.FormSwiper[0];
      }
      console.log(this.FormSwiper);
    }else {
      if (this.FormSwiper) {
        console.log(this.FormSwiper);
      }
      // this.FormSwiper.destroy(true, false);
      this.buildSwiper(0);
      if (this.FormSwiper.length === 2) {
        this.FormSwiper = this.FormSwiper[0];
      }
      console.log(this.FormSwiper);

      // this.FormSwiper.on('slideChange', function () {
      //   console.log('slide changed');
      //   console.log(this.slides[this.activeIndex].clientHeight);
      // });
      // console.dir(this.FormSwiper.slides[this.FormSwiper.activeIndex]);
      // const check = this.FormSwiper.slides[this.FormSwiper.activeIndex];

      // console.dir(this.FormSwiper.slides[this.FormSwiper.activeIndex].children[0].clientHeight);
      // console.log(this.FormSwiper.slides[this.FormSwiper.activeIndex].clientHeight);
      // console.log(this.FormSwiper.activeIndex);
    }
    console.log('Suggest Diagnosis Component ngOnit');

    this.ageGroupOptions = symptomCheckerFormConst.ageGroups;
    this.ageGroupDisplay = symptomCheckerFormConst.getAgeGroups;
    this.genderDisplay = {'f': 'Female', 'm': 'Male'};
    this.regionGroupOptions = symptomCheckerFormConst.regionGroups;
    this.pregnantDisplay = ['not pregnant', 'pregnant'];

    this.buildForm();
    console.log(this.ActRoute.params);
    // console.log(this.getSymptomsSuggestionResults('fev'));
  }

  ngOnChanges(changes: SimpleChanges) {
    console.log('changes');
    // this.buildSwiper();
  }

  buildForm(): void {
    this.suggestForm = this.fb.group({
        'ageGroup':  [this.ageGroup, Validators.required],
        'genderCheck': [this.genderCheck, Validators.required],
        'regionGroup':  [this.regionGroup, Validators.required],
        'pregnant':  [this.pregnant, Validators.required],
    });
    this.ageGroupControls = this.suggestForm.get('ageGroup');
    this.genderCheckControls = this.suggestForm.get('genderCheck');
    this.regionGroupControls = this.suggestForm.get('regionGroup');
    this.pregnantControls = this.suggestForm.get('pregnant');

    // this.SuggestDiagnosisService.getAgeGroup().subscribe(res => {
    //   this.ageGroupOptions = res.age_group;
    //   console.log('ageGroup: ', res.age_group);
    // });
    // this.SuggestDiagnosisService.getRegions().subscribe(res => {
    //   this.regionGroupOptions = res.region;
    //   console.log('regionsGroup', res.region);
    // });
  }

  NextActiveIndex(event): void {
    console.log(this.FormSwiper.activeIndex);
    if (this.FormSwiper.activeIndex === 0) {
      this.onClickContinue();
    }else if (this.FormSwiper.activeIndex === 1) {
      this.onSearchSubmit();
    }else if (this.FormSwiper.activeIndex === 2) {
      if (this.symptomDetails !== undefined) {
        this.FormSwiper.slideNext(1000, true);
      }
    }else if (this.FormSwiper.activeIndex === 3) {
      if (this.articleDetails !== undefined) {
        this.FormSwiper.slideNext(1000, true);
      }
    }
  }

  PrevActiveIndex(e): void {
    console.log(this.FormSwiper.activeIndex);
    if (this.FormSwiper.activeIndex !== 0) {
      this.FormSwiper.slidePrev(1000, true);
      const currSlideHeight = this.FormSwiper.slides[this.FormSwiper.activeIndex].children[0].clientHeight;
      this.FormSwiper.$el.css({
        height: currSlideHeight + 43 + 'px'
      });
    }
  }

  // onEnterAge(event, value): void {
  //   console.log(value);
  // }
  public resetPregnantValue(value): void {
    if (value === true) {
      this.FormSwiper.$el.css({
        height: 100 + '%'
      });
    }else {
      const currSlideHeight = this.FormSwiper.slides[this.FormSwiper.activeIndex].children[0].clientHeight;
      this.FormSwiper.$el.css({
        height: currSlideHeight + 43 + 'px'
      });
    }
    console.log(value);
    this.pregnantControls.setValue('0');
  }

  public onEditBasicDetails(): void {
    this.editBasicHeading = false;
    this.editBasicDetails = false;
  }

  getSuggestDiagnosisResults(ageGroup, genderCheck, regionGroup, pregnant, symptoms, pendingRequests) {
    this.SuggestDiagnosisService.SuggestDifferentialDiagnosis(ageGroup, genderCheck, regionGroup, pregnant, symptoms, pendingRequests).subscribe(res => {
      console.log(res);
    });
  }

  parseWhereNowUrl(url) {
    const whereNowURLTree = this.router.parseUrl(url);
    return {
      age: whereNowURLTree.queryParams.age,
      dx: whereNowURLTree.queryParams.dx,
      pregnancy: whereNowURLTree.queryParams.pregnancy,
      region: whereNowURLTree.queryParams.region,
      sex: whereNowURLTree.queryParams.sex,
      text: whereNowURLTree.queryParams.text
    };
  }

  /** Start Symptom Search Enter Edit Operations **/

  public getSymptomsAsObservable(token: string): Observable<any> {
    const apiURL = 'http://10.64.85.177:8983/solr/symptomChecker/select?wt=json&indent=true&suggest.build=true&suggest.dictionary=SymptomSuggester&suggest.count=6&q=' + token;
    return Observable.from(
      this.http.get(apiURL)
      .map((response: Response) => {
          console.log(response.json().suggest.SymptomSuggester[token].suggestions);
          return response.json().suggest.SymptomSuggester[token].suggestions;
      })
    );
  }

  public onClickContinue () {
    if (this.suggestForm.valid) {
        this.FormSwiper.slideNext(1000, true);
    }else {
      this.FormSwiper.$el.css({
        height: 100 + '100%'
      });
      this.markAllFieldsAsTouched(this.suggestForm);
    }
  }

  markAllFieldsAsTouched(form: FormGroup): void {
      if (form) {
          const allFields: Object = form.controls;
          for (const controlKey of Object.keys(allFields)) {
              if (allFields[controlKey].controls) {
                  this.markAllFieldsAsTouched(allFields[controlKey]);
              } else {
                  allFields[controlKey].markAsTouched();
              }
          }
      }
  }

  public changeShowStatus(): void {
    this.showSymptomSearch = !this.showSymptomSearch;
    // this.symtomEnterMobile.nativeElement.focus();
  }

  public hightlight(match, query): boolean {
    if (match.value === query) {
      console.log(match, query);
      return true;
    }else {
      console.log(match === query);
      return false;
    }
  }

  public typeaheadOnSelect(e: any): void {
    console.log(e);
    console.log('typeaheadOnSelect');
    this.selected = '';
    if (this.symptoms.indexOf(e) === -1) {
      this.symptoms.push(e);
    }
  }
  public onEnterSymptom(value: string): void {
    console.log('onEnterSymptom');
    this.selected = '';
    if (this.symptoms.indexOf(value) === -1 && value !== '') {
      this.symptoms.push(value);
    }
  }

  public onKey(e: any, value: string): void {
    if (e.keyCode === 13) {
      console.log('onEnterSymptom', value);
      this.selected = '';
      if (this.symptoms.indexOf(value) === -1 && value !== '') {
        this.symptoms.push(value);
      }
     }
  }
  public onRemoveSymptomItem(value: string): void {
    const index = this.symptoms.indexOf(value);
    if (index > -1) {
      this.symptoms.splice(index, 1);
    }
  }
  public onResetSymptomItems(value: string): void {
    this.symptoms = [];
  }

  /** End Symptom Form Enter Edit Operations **/

  public showLoadingAndDisplaySearch () {
    const searchContainer = this.document.querySelector('.overlay-parent');
    this.loadingStyle.height = searchContainer.clientHeight + 'px';
    this.loadingStyle.width = searchContainer.clientWidth + 'px';
    this.loadingStyle.display = 'block';
    const searchContanerTop = searchContainer.offsetTop;
    // if (searchContanerTop < $(window).scrollTop()) {
    //   this.loadingSpinnerStyle['margin-top'] = $(window).scrollTop() - searchContanerTop + $(window).height()/2 + "px";
    // } else {
    //   this.loadingSpinnerStyle['margin-top'] = ($(window).height() - (searchContanerTop - $(window).scrollTop()))/2 + "px";
    // }

  }

  public onResize() {
    const searchContainer = this.document.querySelector('.overlay-parent');
    this.loadingStyle.width = searchContainer.clientWidth + 'px';
    this.loadingStyle.height = searchContainer.clientHeight + 'px';
  }

  public onSearchSubmit(): void {
    console.log(this.suggestForm.value);
    // this.router.navigate(['/diagnosis-triage-tool'], { queryParams: { order: 'popular', 'price-range': 'not-cheap' } });
    this.router.navigate(['/suggest-diagnosis/' + this.ageGroupControls.value + '/' + this.genderCheckControls.value + '/' + this.regionGroupControls.value + '/' + this.pregnantControls.value + '/' + this.symptoms.toString()]);
    // this.getSuggestDiagnosisResults(this.suggestForm.value.ageGroup, this.suggestForm.value.genderCheck, this.suggestForm.value.regionGroup, this.suggestForm.value.symptoms);
  }

  public onWhereNow(): void {
    console.log(this.suggestForm.value);
    this.router.navigate(['/diagnosis-triage-tool'], { queryParams: this.triage_tool_QueryParams });
    // this.router.navigate(['/suggest-diagnosis/' + this.suggestForm.value.ageGroup + '/' + this.suggestForm.value.genderCheck + '/' + this.suggestForm.value.regionGroup + '/' + this.suggestForm.value.symptoms]);
  }
  public buildSwiper(index): void {
    this.FormSwiper = new Swiper('.swiper-container', {

      initialSlide: index,
      spaceBetween: 50,
      centeredSlides: true,
      allowTouchMove: false,
      // autoHeight: true,
      // grabCursor: true,
      scrollbar: {
        el: '.swiper-scrollbar',
      },
      keyboard: {
        enabled: true,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true
      },
      on: {
        init: function(){
          if (this.FormSwiper) {
            console.log(this.FormSwiper[0]);
          }
          // this.FormSwiper.destroy(true, false);
          // console.log('First init' + ' ' + index);
        },
        slideChange: function () {
          console.log('slide changed 01');
          const currSlideHeight = this.slides[this.activeIndex].children[0].clientHeight;
          console.log(currSlideHeight);
          if (this.activeIndex === 1 || this.activeIndex === 2) {
            this.$el.css({
                height: 100 + '%'
            });
          }else {
            this.$el.css({
                height: currSlideHeight + 43 + 'px'
            });
          }
        }
      }
    });
  }
  onClickSymptomDetails(details: any): void {
    this.symptomDetailsShow = true;
    if (details.chunkID !== '0') {
      console.log(details.chunkID);
      this.articleDetails = undefined;
      this.SymptomDetailsService.getContentSearchDetails(details.chunkID).subscribe(res => {
        window.scrollTo(0, this.diagnosisResultsId.nativeElement.offsetTop);
        this.FormSwiper.slideNext(1000, true);
        this.symptomDetails = this.sanitizer.bypassSecurityTrustHtml(res._body);
        // console.log(this.symptomDetails);
      });
    }else {
      // console.log(details.symptomName);
      this.articleDetails = undefined;
      window.scrollTo(0, this.diagnosisResultsId.nativeElement.offsetTop);
      this.FormSwiper.slideNext(1000, true);
      this.symptomDetails = details.symptomName;
    }
  }

  onClickArticleDetails(chunkID: String): void {
    this.symptomDetailsShow = true;
    if (chunkID !== undefined && chunkID !== '0') {
      this.SymptomDetailsService.getArticleDetails(chunkID).subscribe(res => {
        window.scrollTo(0, this.symptomDetailsId.nativeElement.offsetTop);
        this.FormSwiper.slideNext(1000, true);
        this.articleDetails = this.sanitizer.bypassSecurityTrustHtml(res._body);
        // console.log(this.symptomDetails);
      });
    }else {
      console.log(chunkID);
    }
  }

  SlideToIndex(index: Number): void {
    this.FormSwiper.slideTo(index, 1);
    const currSlideHeight = this.FormSwiper.slides[this.FormSwiper.activeIndex].children[0].clientHeight;
    this.FormSwiper.$el.css({
        height: currSlideHeight + 43 + 'px'
    });
    // if (this.mySwiper.activeIndex === 6 || this.mySwiper.activeIndex === 7) {
    //   this.isNextValid = false;
    //   this.isPrevValid = true;
    // }else {
    //   this.isNextValid = true;
    //   this.isPrevValid = true;
    //   const Qno = 'Question0' + (this.mySwiper.activeIndex + 1);
    //   if (this.triageToolForm.value[Qno] !== '') {
    //     this.mySwiper.slideNext(1000, true);
    //   }
    // }
  }

  onSetResultsheight(fiilter: any): void {
    setTimeout(() => {
      const currSlideHeight = this.FormSwiper.slides[this.FormSwiper.activeIndex].children[0].clientHeight;
      this.FormSwiper.$el.css({
        height: currSlideHeight + 43 + 'px'
      });
    }, 100);
  }
}


// onSubmit() {
  //   // console.log(this.symptoms.toString());

  //   console.log(this.suggestForm.value);
  //   // this.router.navigate(['/diagnosis-triage-tool'], { queryParams: { order: 'popular', 'price-range': 'not-cheap' } });
  //   this.router.navigate(['/suggest-diagnosis/' + this.suggestForm.value.ageGroup + '/' + this.suggestForm.value.genderCheck + '/' + this.suggestForm.value.regionGroup + '/' + this.symptoms.toString()]);
  //   // this.getSuggestDiagnosisResults(this.suggestForm.value.ageGroup, this.suggestForm.value.genderCheck, this.suggestForm.value.regionGroup, this.suggestForm.value.symptoms);
  // }
