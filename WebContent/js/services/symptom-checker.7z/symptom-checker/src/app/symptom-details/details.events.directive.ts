import { Directive, Renderer, AfterViewInit, ElementRef, Inject, ViewContainerRef, OnInit, OnDestroy, Input, HostListener, OnChanges, HostBinding, SimpleChanges  } from '@angular/core';

import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot,
    RouterStateSnapshot, RouterState } from '@angular/router';
import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';
@Directive({ selector: '[appDetailsEvents]' })
export class DetailsEventsDirective implements OnInit, OnChanges, AfterViewInit {

    CurrentElement: ElementRef;
    router1: Router;
    // @Inject(DOCUMENT) private document: any;

    // @Input('symptomDisplay') symptomDisplay: string;
    // @HostBinding('style.display')
    // @Input() FlexDisplay: string;
    // @HostBinding('class')
    // @Input() classes: string;
    // @HostBinding('symptomDisplay')
    // @Input() symptomDisplayBinding: string;

    @HostListener('mouseenter') onMouseEnter() {
       // console.log(this.symptomDisplay);

       // this.FlexDisplay = 'none';
    }

    ngOnChanges(changes: SimpleChanges) {
        // console.log(el);
    }
    ngOnInit() {
        // console.log(this.CurrentElement.nativeElement.querySelectorAll('div'));
    }

    ngAfterViewInit() {
        console.log(this.document.querySelectorAll('.articleDetailClick'));
        setTimeout(() => {
            console.log(this.document);
            this.document.querySelectorAll('.articleDetailClick').forEach( function ( item ) {
                console.log(item);
                      item.addEventListener('click', function(event) {
                              event.preventDefault();
                              console.log('item-clicked');
                              //  this.router1.navigate(['/suggest-details/666443']);
                       });
                    });
            // this.renderer.listen(this.CurrentElement.nativeElement.querySelectorAll('.articleDetailClick')[1], 'click', (event) => { this.handleClick(event); });

        }, 700);
    }

    constructor(el: ElementRef,
        viewContainerRef: ViewContainerRef,
        private renderer: Renderer,
        @Inject(DOCUMENT) private document: any,
        private router: Router) {
        this.CurrentElement = el;
        this.router1 = router;
        console.log(el);
        console.log(document);
        console.log(viewContainerRef);
        console.log(el.nativeElement.querySelectorAll('div'));
    }
    public handleClick(event) {
        console.log(event);
    }
}

