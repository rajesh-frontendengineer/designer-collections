import { Component, EventEmitter, Input, Output, OnChanges, HostListener, HostBinding, SimpleChanges, Renderer2, OnInit, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, Inject, ViewEncapsulation, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute , Router, NavigationEnd, ResolveEnd, ActivatedRouteSnapshot,
  RouterStateSnapshot, RouterState } from '@angular/router';
import { SafeHtml, SafeResourceUrl, DOCUMENT, DomSanitizer } from '@angular/platform-browser';

import { SymptomDetailsService } from './../services/symptom-details-service';

@Component({
  selector: 'app-symptom-trail-details',
  templateUrl: './symptom-trail-details.component.html',
  styleUrls: ['./symptom-trail-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SymptomTrailDetailsComponent implements OnInit, OnChanges, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked {
    private _SymptomDetails = '';
    private _SymptomWithNoDetails: Object;
    loadingResults: boolean;
    articleSearchCompleted: boolean;
    renderer2: Renderer2;
    @Output() onClickArticleDetails = new EventEmitter<String>();

    @Input()
    set SymptomDetails(SymptomDetails: any){
        if (typeof SymptomDetails === 'object') {
          this.loadingResults = false;
          this._SymptomDetails = SymptomDetails;
          this._SymptomWithNoDetails = undefined;
        }else {
          this.loadingResults = false;
          this._SymptomDetails = undefined;
          this._SymptomWithNoDetails = {
            'SymptomName' : SymptomDetails,
            'MayoClinc': 'http://www.mayoclinic.org/search/search-results?q=' + SymptomDetails,
            'MedlinePlus': 'http://vsearch.nlm.nih.gov/vivisimo/cgi-bin/query-meta?v%3Aproject=medlineplus&query=' + SymptomDetails,
            'WebMD': 'http://www.webmd.com/search/search_results/default.aspx?query=' + SymptomDetails
          };
        }
    }
    get SymptomDetails(): any{
      return this._SymptomDetails;
    }
    get SymptomWithNoDetails(): any{
      return this._SymptomWithNoDetails;
    }

    constructor(
        private ActRoute: ActivatedRoute,
        private router: Router,
        private SymptomDetailsService: SymptomDetailsService,
        private sanitizer: DomSanitizer,
        el: ElementRef,
        @Inject(DOCUMENT) private document: any,
        renderer: Renderer2
      ) {
        this.renderer2 = renderer;
        this.loadingResults = true;
      }

    ngOnInit() {
      this.articleSearchCompleted = false;
      console.log('ngOnInit');
    }

    ngOnChanges(changes: SimpleChanges) {
      setTimeout(() => {
        console.log('ngAfterViewInit timeout');
        console.log(this.document.querySelectorAll('.articleSearchClick'));
          this.document.querySelectorAll('.articleSearchClick').forEach( ( item ) => {
            console.log(item.id);
                  this.renderer2.listen(item, 'click', (event) => {
                    this.articleSearchCompleted = true;
                    // Do something with 'event'
                    event.preventDefault();
                    console.log('item-clicked');
                    // this.router.navigate(['/article-details/' + item.id]);
                    this.onArticleDetails(item.id);
                  });
                  // item.addEventListener('click', function(event) {
                  //         event.preventDefault();
                  //         console.log('item-clicked');
                  //         console.log(this.router);
                  //         // this.router.navigate(['/suggest-diagnosis']);
                  //         this.onsubmit();
                  // });
          });
        // this.renderer.listen(this.CurrentElement.nativeElement.querySelectorAll('.articleDetailClick')[1], 'click', (event) => { this.handleClick(event); });
       }, 1000);
    }

    public onArticleDetails(chunkID: String): void {
        this.onClickArticleDetails.emit(chunkID);
    }


    ngAfterContentInit() {
      console.log('ngAfterContentInit');
    }
    ngAfterContentChecked() {
      // console.log('ngAfterContentChecked');
    }
    ngAfterViewInit() {
        console.log('ngAfterViewInit');
        // console.log(this.document.querySelectorAll('.articleSearchClick'));
        // setTimeout(() => {
        //     console.log('ngAfterViewInit timeout');
        //     console.log(this.document.querySelectorAll('.articleSearchClick'));
        //     if (!this.articleSearchCompleted) {
        //       this.document.querySelectorAll('.articleSearchClick').forEach( ( item ) => {
        //         console.log(item.id);
        //         this.renderer2.listen(item, 'click', (event) => {
        //           this.articleSearchCompleted = true;
        //           // Do something with 'event'
        //           event.preventDefault();
        //           console.log('item-clicked');
        //           // this.router.navigate(['/article-details/' + item.id]);
        //           this.onArticleDetails(item.id);
        //         });
        //       });
        //     }
        //     // this.renderer.listen(this.CurrentElement.nativeElement.querySelectorAll('.articleDetailClick')[1], 'click', (event) => { this.handleClick(event); });
        // }, 1100);
    }
    ngAfterViewChecked() {
      // if (!this.articleSearchCompleted) {
      //     console.log('ngAfterViewChecked');
      //     this.document.querySelectorAll('.articleSearchClick').forEach( ( item ) => {
      //       console.log(item.id);
      //       this.renderer2.listen(item, 'click', (event) => {
      //         this.articleSearchCompleted = true;
      //         // Do something with 'event'
      //         event.preventDefault();
      //         console.log('item-clicked');
      //         // this.router.navigate(['/article-details/' + item.id]);
      //         this.onArticleDetails(item.id);
      //       });
      //     // item.addEventListener('click', function(event) {
      //     //         event.preventDefault();
      //     //         console.log('item-clicked');
      //     //         console.log(this.router);
      //     //         // this.router.navigate(['/suggest-diagnosis']);
      //     //         this.onsubmit();
      //     // });
      //   });
      // }
    }
}
